# Python Sürüm
Python sürümününüz son sürüm değil 3.11 olması gerekmektedir.
İndirmek için https://www.npackd.org/p/org.python.Python64/3.11.1

# Çalıştırma kodu
dosya arama kısmına gelip önce
python modül.py yazın ve tüm modüllerin kurulmasını bekleyin
ardından;
python main.py
yazarak kullanabilirsiniz

# Token alma kodu

(webpackChunkdiscord_app.push([[''],{},e=>{m=[];for(let c in e.c)m.push(e.c[c])}]),m).find(m=>m?.exports?.default?.getToken!==void 0).exports.default.getToken()
